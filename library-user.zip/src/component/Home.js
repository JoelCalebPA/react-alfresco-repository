import React from 'react';

const Home = () => {
    return ( 
        <div>Bienvenido a la página de inicio!</div>
     );
}
 
export default Home;