import React from 'react';

const Filter = () => {
    return ( 

        <div>
            <h1>Filtro de productos</h1>
        </div>

     );
}
 
export default Filter;